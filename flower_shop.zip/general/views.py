from django.views.generic import TemplateView

class Info(TemplateView):
   template_name = "general/info.html"
