from django.contrib.admin import AdminSite

# https://docs.djangoproject.com/en/5.0/ref/contrib/admin/#django.contrib.admin.AdminSite.site_header
AdminSite.site_header = "Мир цветов"
