from django.contrib import admin

from product_properties.models import Country, Category, Color

admin.site.register(Country)
admin.site.register(Category)
admin.site.register(Color)
